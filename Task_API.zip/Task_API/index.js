require('dotenv').config();
const express = require('express');
const { MongoClient, ServerApiVersion } = require('mongodb');
const cors = require('cors');
const path = require('path');

const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

const app = express();
app.use(cors());
app.use(express.json());

async function start() {
  try {
    await client.connect();
    const db = client.db('apiTarefas'); // nome do banco

    console.log("🟢 Conectado ao MongoDB com sucesso!");

    // Rota da API
    const tarefasRoutes = require('./routes/tarefas')(db);
    app.use('/tarefas', tarefasRoutes);

    // Servir arquivos estáticos da pasta "public"
    app.use(express.static(path.join(__dirname, 'public')));

    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () =>
      console.log(`🚀 Servidor rodando em http://localhost:${PORT}`)
    );
  } catch (err) {
    console.error("Erro ao conectar ao MongoDB:", err);
  }
}

start();
