const express = require('express');
const { ObjectId } = require('mongodb');
const router = express.Router();

module.exports = (db) => {
  const collection = db.collection('tarefas');

  // Criar
  router.post('/', async (req, res) => {
    try {
      const result = await collection.insertOne(req.body);
      res.status(201).json(result.ops?.[0] || req.body); // ops pode estar depreciado em versões novas
    } catch (error) {
      res.status(400).json({ erro: error.message });
    }
  });

  // Listar todas
  router.get('/', async (req, res) => {
    const tarefas = await collection.find().toArray();
    res.json(tarefas);
  });

  // Buscar por ID
  router.get('/:id', async (req, res) => {
    try {
      const tarefa = await collection.findOne({ _id: new ObjectId(req.params.id) });
      if (!tarefa) return res.status(404).json({ erro: "Tarefa não encontrada" });
      res.json(tarefa);
    } catch (error) {
      res.status(400).json({ erro: "ID inválido" });
    }
  });

  // Atualizar (PUT)
  router.put('/:id', async (req, res) => {
    try {
      const result = await collection.findOneAndUpdate(
        { _id: new ObjectId(req.params.id) },
        { $set: req.body },
        { returnDocument: 'after' }
      );
      if (!result.value) return res.status(404).json({ erro: "Tarefa não encontrada" });
      res.json(result.value);
    } catch (error) {
      res.status(400).json({ erro: error.message });
    }
  });

  // Deletar
  router.delete('/:id', async (req, res) => {
    try {
      const result = await collection.deleteOne({ _id: new ObjectId(req.params.id) });
      if (result.deletedCount === 0) return res.status(404).json({ erro: "Tarefa não encontrada" });
      res.json({ mensagem: "Tarefa deletada com sucesso" });
    } catch (error) {
      res.status(400).json({ erro: "ID inválido" });
    }
  });

  return router;
};
